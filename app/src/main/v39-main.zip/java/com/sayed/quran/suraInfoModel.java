package com.sayed.quran;

public class suraInfoModel {
    String sura_title, meaning, ayah_count;
}
