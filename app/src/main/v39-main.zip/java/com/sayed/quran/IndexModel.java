package com.sayed.quran;

public class IndexModel {
    String sura, title, meaning, ayah_count;

    public IndexModel(String sura, String title, String meaning, String ayah_count) {
        this.sura = sura;
        this.title = title;
        this.meaning = meaning;
        this.ayah_count = ayah_count;
    }

}
