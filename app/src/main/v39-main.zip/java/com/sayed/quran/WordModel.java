package com.sayed.quran;

public class WordModel {
    String arabic, translation;
}
