package com.sayed.quran;

public class ThemeModel {
    public String name;
    public int myColor, myBackground, myTextColor, myTheme;

    public ThemeModel(String name, int myColor, int myBackground, int myTextColor, int myTheme) {
        this.name = name;
        this.myColor = myColor;
        this.myBackground = myBackground;
        this.myTextColor = myTextColor;
        this.myTheme = myTheme;
    }
}
