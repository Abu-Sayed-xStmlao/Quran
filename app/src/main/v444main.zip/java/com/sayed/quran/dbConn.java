package com.sayed.quran;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class dbConn extends SQLiteOpenHelper {
    public static final String DB_PATH = "/storage/emulated/0/Android/fts/";
    public static final String INDEX_DB = "index.db"; //index db file
    public static final String QURAN_DB = "quran.db"; //main db file
    public static final String WORDS_DB = "words.db"; //words db file
    public static final String CORPUS_DB = "corpus.db"; //words db file
    public static final int DB_VERSION = 1;
    public static String TRANSLATION_DB = "en_sahih.db"; //translation db file
    public static String TAFSIR_DB = "kathir.db"; //tafsir db file
    public final Context context;
    public SQLiteDatabase database;

    public dbConn(@Nullable Context context) {
        // Pass only main DB name to SQLiteOpenHelper
        super(context, DB_PATH + INDEX_DB, null, DB_VERSION);
        this.context = context;
    }


    //define index database
    public SQLiteDatabase getIndexDb() {
        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                DB_PATH + INDEX_DB,
                null,
                SQLiteDatabase.OPEN_READWRITE
        );
        return db;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Not needed for pre-populated databases
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Example for update
    }


    public ArrayList<IndexModel> getIndex() {
        ArrayList<IndexModel> indexList = new ArrayList<>();
        SQLiteDatabase database = getIndexDb();
        String lang = LanguagePref.getLanguage(context);
        // Use try-with-resources to ensure automatic resource cleanup
        try (Cursor cursor = database.rawQuery("SELECT * FROM sura ", null)) {
            if (cursor.moveToFirst()) {
                do {
                    String sura = cursor.getInt(cursor.getColumnIndexOrThrow("sura")) + "";
                    String title = cursor.getString(cursor.getColumnIndexOrThrow("name_" + lang));
                    String meaning = cursor.getString(cursor.getColumnIndexOrThrow("meaning"));
                    String ayah_count = cursor.getInt(cursor.getColumnIndexOrThrow("ayat_count")) + "";

                    IndexModel model = new IndexModel(sura, title, meaning, ayah_count);
                    indexList.add(model);
                } while (cursor.moveToNext());
            }
        }

        database.close();
        return indexList;
    }

    public ArrayList<IndexModel> getIndex(String find) {
        ArrayList<IndexModel> indexList = new ArrayList<>();
        SQLiteDatabase database = getIndexDb();
        String lang = LanguagePref.getLanguage(context);
        // Use try-with-resources to ensure automatic resource cleanup


        Cursor cursor = database.rawQuery(
                "SELECT * FROM sura WHERE name_en LIKE ? OR name_bn LIKE ? OR name_hn LIKE ? OR meaning LIKE ? OR sura LIKE ?",
                new String[]{"%" + find + "%", "%" + find + "%", "%" + find + "%", "%" + find + "%", "%" + find + "%"}
        );


        try (cursor) {
            if (cursor.moveToFirst()) {
                do {
                    String sura = cursor.getInt(cursor.getColumnIndexOrThrow("sura")) + "";
                    String title = cursor.getString(cursor.getColumnIndexOrThrow("name_" + lang));
                    String meaning = cursor.getString(cursor.getColumnIndexOrThrow("meaning"));
                    String ayah_count = cursor.getInt(cursor.getColumnIndexOrThrow("ayat_count")) + "";

                    IndexModel model = new IndexModel(sura, title, meaning, ayah_count);

                    indexList.add(model);
                } while (cursor.moveToNext());
            }
        }

        database.close();
        return indexList;
    }


    //define arabic, translation, words database
    public SQLiteDatabase getATWDatabase() {
        String language = LanguagePref.getLanguage(context);
        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                DB_PATH + QURAN_DB,
                null,
                SQLiteDatabase.OPEN_READWRITE
        );


        switch (language) {
            case "bn":
                TRANSLATION_DB = "bn_taisirul.db";
                break;
            case "hn":
                TRANSLATION_DB = "hi_nadwi.db";
                break;
            default:
                TRANSLATION_DB = "en_sahih.db";
                break;
        }


        // db.execSQL("ATTACH DATABASE '" + DB_PATH + QURAN_DB + "' AS arDB");
        db.execSQL("ATTACH DATABASE '" + DB_PATH + TRANSLATION_DB + "' AS trDB");
        db.execSQL("ATTACH DATABASE '" + DB_PATH + WORDS_DB + "' AS wordsDB");
        return db;
    }


    public ArrayList<VerseModel> getVerses(int sura) {
        String language = LanguagePref.getLanguage(context);
        language = language.replace("hn", "hi");
        ArrayList<VerseModel> versesList = new ArrayList<>();
        SQLiteDatabase database = getATWDatabase();
        String exploder = "__#";

        String verseQuery =
                "SELECT " +
                        "  vc.c0sura AS sura, " +
                        "  vc.c1ayah AS ayah, " +
                        "  vc.c2text AS arabic, " +
                        "  tr.c2text AS translation, " +
                        "  GROUP_CONCAT('" + exploder + "' || w." + language + ", '') AS words " +
                        "FROM verses_content AS vc " +
                        "INNER JOIN trDB.verses_content AS tr " +
                        "  ON vc.c0sura = tr.c0sura " +
                        "  AND vc.c1ayah = tr.c1ayah " +
                        "LEFT JOIN wordsDB.allwords AS w " +  // ✅ LEFT JOIN is better
                        "  ON vc.c0sura = w.sura " +
                        "  AND vc.c1ayah = w.ayah " +
                        "WHERE vc.c0sura =  " + sura + " " +
                        "GROUP BY vc.c0sura, vc.c1ayah " +
                        "ORDER BY vc.c0sura, vc.c1ayah";

        try (Cursor cursor = database.rawQuery(verseQuery, null)) {
            if (cursor.moveToFirst()) {
                int ayahCol = cursor.getColumnIndexOrThrow("ayah");
                int arabicCol = cursor.getColumnIndexOrThrow("arabic");
                int transCol = cursor.getColumnIndexOrThrow("translation");
                int wordsCol = cursor.getColumnIndexOrThrow("words");

                do {
                    String ayah = cursor.getString(ayahCol);
                    String arabic = cursor.getString(arabicCol);
                    String translation = cursor.getString(transCol);
                    String words = cursor.getString(wordsCol);

                    // Fast lookup from cached words map
                    versesList.add(new VerseModel(sura + "", ayah, arabic, translation, words));
                } while (cursor.moveToNext());
            }
        }

        database.close();
        return versesList;
    }


    public ArrayList<suraInfoModel> getSuraInfo(String sura_no) {
        ArrayList<suraInfoModel> suraInfo = new ArrayList<>();
        String lang = LanguagePref.getLanguage(context);
        SQLiteDatabase database = getIndexDb();
        // Use try-with-resources to ensure automatic resource cleanup
        try (Cursor cursor = database.rawQuery("SELECT * FROM sura WHERE sura = ?", new String[]{sura_no})) {
            if (cursor.moveToFirst()) {
                do {
                    String sura_title = cursor.getString(cursor.getColumnIndexOrThrow("name_" + lang));
                    String meaning = cursor.getString(cursor.getColumnIndexOrThrow("meaning"));
                    String ayat_count = cursor.getInt(cursor.getColumnIndexOrThrow("ayat_count")) + "";
                    suraInfoModel suraInfoModel = new suraInfoModel();
                    suraInfoModel.sura_title = sura_title;
                    suraInfoModel.meaning = meaning;
                    suraInfoModel.ayah_count = ayat_count;

                    suraInfo.add(suraInfoModel);

                } while (cursor.moveToNext());
            }
        }

        database.close();
        return suraInfo;
    }


    public ArrayList<VerseModel> findVerses(String finder) {
        ArrayList<VerseModel> versesList = new ArrayList<>();
        SQLiteDatabase database = getATDatabase();

        String lang = LanguagePref.getLanguage(context);

        // Step 2: Load all verses with translations
        // Step 2: Load all verses with translations
        String verseQuery = "SELECT " +
                "vc.c0sura AS sura, " +
                "vc.c1ayah AS ayah, " +
                "vc.c2text AS arabic, " +
                "tr.c2text AS translation " +
                "FROM verses_content vc " +
                "INNER JOIN trDB.verses_content tr " +
                "ON tr.c0sura = vc.c0sura AND " +
                "tr.c1ayah = vc.c1ayah " +
                "INNER JOIN arDB.verses_content ar " +
                "ON tr.c0sura = ar.c0sura AND " +
                "tr.c1ayah = ar.c1ayah  " +
                "WHERE " +
                "vc.c2text LIKE ? OR " +
                "tr.c2text LIKE ? OR " +
                "ar.c2text LIKE ?  ";
        try (Cursor cursor = database.rawQuery(verseQuery, new String[]{"%" + finder + "%", "%" + finder + "%", "%" + finder + "%"})) {
            if (cursor.moveToFirst()) {
                int suraCol = cursor.getColumnIndexOrThrow("sura");
                int ayahCol = cursor.getColumnIndexOrThrow("ayah");
                int arabicCol = cursor.getColumnIndexOrThrow("arabic");
                int transCol = cursor.getColumnIndexOrThrow("translation");

                do {
                    String sura = cursor.getString(suraCol);
                    String ayah = cursor.getString(ayahCol);
                    String arabic = cursor.getString(arabicCol);
                    String translation = cursor.getString(transCol);

                    versesList.add(new VerseModel(sura, ayah, arabic, translation, ""));
                } while (cursor.moveToNext());
            }
        }

        database.close();
        return versesList;
    }


    public SQLiteDatabase getATDatabase() {
        String language = LanguagePref.getLanguage(context);
        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                DB_PATH + QURAN_DB,
                null,
                SQLiteDatabase.OPEN_READWRITE
        );


        switch (language) {
            case "bn":
                TRANSLATION_DB = "bn_taisirul.db";
                break;
            case "hn":
                TRANSLATION_DB = "hi_nadwi.db";
                break;
            default:
                TRANSLATION_DB = "en_sahih.db";
                break;
        }


        db.execSQL("ATTACH DATABASE '" + DB_PATH + "quran_ar.db" + "' AS arDB");
        db.execSQL("ATTACH DATABASE '" + DB_PATH + TRANSLATION_DB + "' AS trDB");
        db.execSQL("ATTACH DATABASE '" + DB_PATH + WORDS_DB + "' AS wordsDB");
        return db;
    }


    public ArrayList<VerseModel> loadVerses() {
        ArrayList<VerseModel> versesList = new ArrayList<>();
        SQLiteDatabase database = getATDatabase();

        String lang = LanguagePref.getLanguage(context);

        // Step 2: Load all verses with translations
        String verseQuery = "SELECT " +
                "vc.c0sura AS sura, " +
                "vc.c1ayah AS ayah, " +
                "vc.c2text AS arabic, " +
                "tr.c2text AS translation " +
                "FROM verses_content vc " +
                "INNER JOIN trDB.verses_content tr " +
                "ON tr.c0sura = vc.c0sura AND " +
                "tr.c1ayah = vc.c1ayah " +
                "INNER JOIN arDB.verses_content ar " +
                "ON tr.c0sura = ar.c0sura AND " +
                "tr.c1ayah = ar.c1ayah  " +
                "LIMIT 100";
        try (Cursor cursor = database.rawQuery(verseQuery, new String[]{})) {
            if (cursor.moveToFirst()) {
                int suraCol = cursor.getColumnIndexOrThrow("sura");
                int ayahCol = cursor.getColumnIndexOrThrow("ayah");
                int arabicCol = cursor.getColumnIndexOrThrow("arabic");
                int transCol = cursor.getColumnIndexOrThrow("translation");

                do {
                    String sura = cursor.getString(suraCol);
                    String ayah = cursor.getString(ayahCol);
                    String arabic = cursor.getString(arabicCol);
                    String translation = cursor.getString(transCol);

                    versesList.add(new VerseModel(sura, ayah, arabic, translation, ""));
                } while (cursor.moveToNext());
            }
        }

        database.close();
        return versesList;
    }

    public String getTafsir(int sura, int ayah) {


        String language = LanguagePref.getLanguage(context);


        switch (language) {
            case "bn":
                TAFSIR_DB = "bn_tafsir_kathir.db";
                break;
            case "hn":
                TAFSIR_DB = "ur_maududi.db";
                break;
            default:
                TAFSIR_DB = "kathir.db";
                break;
        }


        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                DB_PATH + TAFSIR_DB,
                null,
                SQLiteDatabase.OPEN_READWRITE
        );


        String tafsir = "";
        String sql = "SELECT c2text FROM verses_content WHERE c0sura = " + sura + " AND c1ayah = " + ayah;
        try (Cursor cursor = db.rawQuery(sql, null)) {
            if (cursor.moveToFirst()) {
                tafsir = cursor.getString(cursor.getColumnIndexOrThrow("c2text"));
            }
        }
        return tafsir;
    }
}
