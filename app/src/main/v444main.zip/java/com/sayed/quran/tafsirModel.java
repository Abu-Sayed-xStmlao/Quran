package com.sayed.quran;

public class tafsirModel {
    String tafsir;

    public tafsirModel(String tafsir) {
        this.tafsir = tafsir;
    }
}
